# Ray Azevedo — Site de Agendamento

Versão sem fotos: o site usa apenas a identidade visual preta e dourada e elementos gráficos.
O formulário solicita o agendamento e abre o WhatsApp com a mensagem pronta.

Antes de publicar, confirme o número do WhatsApp e os serviços/horários do salão.
